from __future__ import unicode_literals
from django.db import models


class professor(models.Model):
    prof_id = models.IntegerField(default=0)
    prof_name = models.CharField(max_length=100)
    course_name = models.CharField(max_length=150)


class student(models.Model):
    stud_id = models.IntegerField(default=0)
    stud_name = models.CharField(max_length=100)

class attendance(models.Model):
	course = models.ForeignKey(professor, on_delete=models.CASCADE)
	student = models.ForeignKey(student, on_delete=models.CASCADE)
	pub_date = models.DateTimeField('date published')