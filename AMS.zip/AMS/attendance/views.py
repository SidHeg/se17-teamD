from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from django.template import loader
from .models import professor
import json

def index(request):
    return HttpResponse("Hello, world. You're at the Attendance Management System.")

def gps(request, prof_id):
	p = get_object_or_404(professor, pk=prof_id)
	response =  p.prof_name +', '+ p.course_name
	return HttpResponse(response)